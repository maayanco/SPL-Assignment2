package bgu.spl.run;

import bgu.spl.app.DiscountSchedule;

public class Manager {
	private Discount[] discountSchedule;

	public Discount[] getDiscountSchedule(){
		return discountSchedule;
	}
}
