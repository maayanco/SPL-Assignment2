package bgu.spl.run;

public class Discount {
	private String shoeType;
	private int amount;
	private int tick;
	
	public String getShoeType(){
		return shoeType;
	}
	
	public int getAmount(){
		return amount;
	}
	
	public int getTick(){
		return tick;
	}
}
