package bgu.spl.run;

public class Storage {
	private String shoeType;
	private int amount;
	
	public String getShoeType(){
		return shoeType;
	}
	
	public int getAmount(){
		return amount;
	}
}
