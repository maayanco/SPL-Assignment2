package bgu.spl.run;

public class Time {
	private int speed;
	private int duration;

	public int getSpeed(){
		return speed;
	}
	
	public int getDuration(){
		return duration;
	}
}
