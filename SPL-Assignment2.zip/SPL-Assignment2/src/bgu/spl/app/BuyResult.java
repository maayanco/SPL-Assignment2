package bgu.spl.app;

public enum BuyResult {
	NOT_IN_STOCK, NOT_ON_DISCOUNT, REGULAR_PRICE, DISCOUNTED_PRICE;
}
